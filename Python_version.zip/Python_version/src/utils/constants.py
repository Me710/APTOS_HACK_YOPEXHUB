NODE_URL = "https://fullnode.devnet.aptoslabs.com/v1"
FAUCET_URL = "https://faucet.devnet.aptoslabs.com"
YOPEX_MODULE_ADDRESS = "0x9cfb5f869b27d71d882524530aecdbe4e40d94006cccd41dd373f34f6acf51ae"
YOPEX_MODULE_NAME = "yopex"